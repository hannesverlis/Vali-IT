﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VacApp_V0._1.Models;



namespace VacApp_V0._1.Controllers
{

    [Authorize(Roles = "admin")]
    public class UsersController : Controller
    {

        public static AspNetUser GetByEmail(string email)
        {
            using (VacationEntities db = new VacationEntities())
            {
                return db.AspNetUsers.Where(x => x.Email == email).SingleOrDefault();
            }
        }


        private VacationEntities db = new VacationEntities();

        // GET: Users
        public ActionResult Index()
        {
            ViewBag.Roles = db.AspNetRoles.ToList();
            return View(db.AspNetUsers.Include("AspNetRoles").ToList());
        }

        // GET: Users/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AspNetUser aspNetUser = db.AspNetUsers.Find(id);
            if (aspNetUser == null)
            {
                return HttpNotFound();
            }
            return View(aspNetUser);
        }

        // GET: Users/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Users/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName,DisplayName,BirthDate,FirstName,LastName")] AspNetUser aspNetUser)
        {
            if (ModelState.IsValid)
            {
                db.AspNetUsers.Add(aspNetUser);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(aspNetUser);
        }

        // GET: Users/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AspNetUser aspNetUser = db.AspNetUsers.Find(id);
            if (aspNetUser == null)
            {
                return HttpNotFound();
            }
            ViewBag.Roles = db.AspNetRoles.ToList();

            return View(aspNetUser);
        }

        // POST: Users/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Email,EmailConfirmed,PasswordHash,SecurityStamp,PhoneNumber,PhoneNumberConfirmed,TwoFactorEnabled,LockoutEndDateUtc,LockoutEnabled,AccessFailedCount,UserName,DisplayName,BirthDate,FirstName,LastName")] AspNetUser aspNetUser)
        {
            if (ModelState.IsValid)
            {
                db.Entry(aspNetUser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(aspNetUser);
        }

        // GET: Users/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            AspNetUser aspNetUser = db.AspNetUsers.Find(id);
            if (aspNetUser == null)
            {
                return HttpNotFound();
            }
            return View(aspNetUser);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            AspNetUser aspNetUser = db.AspNetUsers.Find(id);
            db.AspNetUsers.Remove(aspNetUser);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "admin")]
        public ActionResult AddRole(string id, string roleId)
        {

            AspNetUser user = db.AspNetUsers.Find(id);
            AspNetRole role = db.AspNetRoles.Find(roleId);
            
                if (user.Email != User.Identity.Name || role.Name != "admin")
                    

                    {
                try
                {
                    user.AspNetRoles.Add(role);
                    db.SaveChanges();
                }
                catch (Exception)
                {
                }
            }
            return RedirectToAction("Edit", new { id });
        }

        [Authorize(Roles = "admin")]
        public ActionResult RemoveRole(string id, string roleId)
        {

            AspNetUser user = db.AspNetUsers.Find(id);
            AspNetRole role = db.AspNetRoles.Find(roleId);
           
            if (user.Email != User.Identity.Name || role.Name != "admin")
                if (role.Name != "admin" || role.AspNetUsers.Count() > 1)
                {
                try
                {
                    user.AspNetRoles.Remove(role);
                    db.SaveChanges();
                }
                catch (Exception)
                {
                }
            }
            return RedirectToAction("Edit", new { id });
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
