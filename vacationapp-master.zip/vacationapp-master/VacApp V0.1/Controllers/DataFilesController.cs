﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VacApp_V0._1.Models;

namespace VacApp_V0._1.Controllers
{
    public class DataFilesController : Controller
    {
        VacationEntities db = new VacationEntities();

        public ActionResult Content(int id = 0)
        {
            DataFile f = db.DataFiles.Find(id);
            if (f == null) return HttpNotFound();
            return File(f.Content, f.ContentType);
        }
    }
    
 }
