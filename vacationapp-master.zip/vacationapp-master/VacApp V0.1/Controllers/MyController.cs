﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using VacApp_V0._1.Models;

namespace VacApp_V0._1.Controllers
{
    public class MyController : Controller
    {

        protected VacationEntities db = new VacationEntities();

        AspNetUser currentUser = null;
        protected AspNetUser CurrentUser =>
            currentUser ??
            (currentUser = db.AspNetUsers.Where(x => x.Email == User.Identity.Name).SingleOrDefault());

        Person currentPerson = null;
        protected Person CurrentPerson =>
            currentPerson ??
            (currentPerson = db.People.Where(x => x.Email == User.Identity.Name).SingleOrDefault());

        protected void ChangeDataFile(HttpPostedFileBase file, Action<int> change, int? oldId)
        {

            if (file != null && file.ContentLength > 0)
            {
                using (BinaryReader br = new BinaryReader(file.InputStream))
                {
                    DataFile f = new DataFile
                    {
                        Content = br.ReadBytes(file.ContentLength),
                        ContentType = file.ContentType,
                        FileName = file.FileName.Split('\\').Last().Split('/').Last(),
                        Created = DateTime.Now
                    };
                    db.DataFiles.Add(f);
                    db.SaveChanges();
                    change(f.Id);
                    if (oldId.HasValue)
                    {
                        db.DataFiles.Remove(db.DataFiles.Find(oldId.Value));
                        db.SaveChanges();
                    }
                }
            }
        }

    }   
}
