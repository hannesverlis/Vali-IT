﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VacApp_V0._1.Models;
using System.ComponentModel.DataAnnotations;
using Nager.Date;
using System.IO;

namespace VacApp_V0._1.Models
{
    public class PersonMetadata
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required]
        [Display(Name = "Personal ID")]
        public string IK { get; set; }

        [Display(Name = "Department")]
        public int DepartmentId { get; set; }
        [Required]
        public string Position { get; set; }

        [Required]
        [Display(Name = "Hire Date")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public Nullable<System.DateTime> HireDate { get; set; }

        [Required]
        [Display(Name = "Standard days")]
        public int StandardDays { get; set; }

        [Required]
        [Display(Name = "Unused days from past")]
        public Nullable<int> UnusedDaysPast { get; set; }

        [Display(Name = "Unused days")]
        public Nullable<int> UnusedDaysCurrent { get; set; }
        public Nullable<int> ExtraDays { get; set; }
        public Nullable<int> PictureId { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public System.DateTime Created { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd.MM.yyyy}")]
        public System.DateTime Modified { get; set; }
        [Required]
        [Display(Name = "E-mail")]
        public string Email { get; set; }

        public virtual DataFile DataFile { get; set; }
        public virtual Department Department { get; set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Vacation> Vacations { get; set; }

    }

    [MetadataType(typeof(PersonMetadata))]
    partial class Person
    {
        [Display(Name = "Full name")]
        public string FullName => $"{FirstName} {LastName}";

        // Kasutada olnud PÕHIpuhkusepäevad vahemikus viimane aastavahetus kuni inimese andmebaasi lisamise (Person Created Date) või töölehakkamise kuupäevani, aga mitte varasemalt kui Create
        public int PossibleDaysPast =>
            (HireDate.Value.Year < DateTime.Now.Year && HireDate > Created ?

            (StandardDays * (new DateTime(DateTime.Now.Year, 1, 1) - HireDate.Value).Days) / ((4 * 365 + 1) / 4) :

            (HireDate.Value.Year < DateTime.Now.Year && HireDate < Created && Created.Year < DateTime.Now.Year ? (StandardDays * (new DateTime(DateTime.Now.Year, 1, 1) - Created).Days) / ((4 * 365 + 1) / 4) : 0));

        // abiparameeter  - staaž eelmise aasta lõpu seisuga
        public decimal ExperienceBeforeCurrent =>

             (HireDate.Value.Year < DateTime.Now.Year ? (new DateTime(DateTime.Now.Year, 1, 1) - HireDate.Value).Days / ((4 * 365 + 1) / 4) : 0);

        // abiparameeter - kogemus ajavahemikus Create - HireDate (kui HireDate < Create)

        public decimal ExperienceBeforeCreate =>
             (Created - HireDate.Value).Days / ((4 * 365 + 1) / 4);

        // Kasutada olnud staažipäevad vahemikus viimane aastavahetus kuni inimese andmebaasi lisamise (Person Created Date) või töölehakkamise kuupäevani, aga mitte varasemalt kui Create
        public decimal XtraDaysPast =>
           (HireDate >= Created ?
            (
            (ExperienceBeforeCurrent <= 5 ?

            (ExperienceBeforeCurrent / 2) * (ExperienceBeforeCurrent + 1) :

            (ExperienceBeforeCurrent > 5 ?

            ((ExperienceBeforeCurrent - 5) * 5 + 15) : 0))
            )

            :
            (
            (ExperienceBeforeCurrent <= 5 && Created.Year < DateTime.Now.Year ?

            (ExperienceBeforeCurrent / 2) * (ExperienceBeforeCurrent + 1) - (ExperienceBeforeCreate / 2) * ((Created - HireDate.Value).Days / ((4 * 365 + 1) / 4) + 1) :

            (ExperienceBeforeCurrent > 5 && Created.Year < DateTime.Now.Year ?

            ((ExperienceBeforeCurrent - 5) * 5 + 15) -

            ((Created - HireDate.Value).Days / ((4 * 365 + 1) / 4) <= 5 && Created.Year < DateTime.Now.Year ? (ExperienceBeforeCreate / 2) * ((Created - HireDate.Value).Days / ((4 * 365 + 1) / 4) + 1) : ((ExperienceBeforeCreate - 5) * 5 + 15)
            )
            : 0))));

        //  Kasutatud PÕHIpuhkusepäevad vahemikus viimane aastavahetus kuni inimese andmebaasi lisamise (Person Created Date) või tööle hakkamise kuupäevani , aga mitte varasemalt kui Create
        public int UsedDaysPast =>
            Vacations
                  .Where(x => x.EndDate > x.Person.Created)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate.Value.Year < DateTime.Now.Year)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)                                                                     // (State = 1) ainult kinnitatud puhkused!
                  .Select(x =>
                      (x.StartDate > x.Person.Created ?

                      (x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                      ((new DateTime(DateTime.Now.Year, 1, 1).AddDays(-1) - x.StartDate.Value).Days + 1) :
                      (x.EndDate.Value - x.StartDate.Value).Days + 1)
                      :
                      (x.EndDate.Value - x.Person.Created).Days +1))
                  .Sum()
          
                  -

             Vacations
                  .Where(x => x.EndDate > x.Person.Created)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate.Value.Year < DateTime.Now.Year)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Select(x =>
                      x.StartDate > x.Person.Created ?

                      (x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                      (DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, (new DateTime(DateTime.Now.Year, 1, 1).AddDays(-1))).Count()) :
                          DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count())
                  :
                  DateSystem.GetPublicHoliday(CountryCode.EE, x.Person.Created, x.EndDate.Value).Count())
                  .Sum();

        // Minevikust käesolevasse aastase lisanduvad kasutamata puhkusepäevad (ei arvesta päevi, mis tulevad kaasa Person Create eelsest ajast, need tuleb inimese lisamisel käsitsi sisestada)
        [Display(Name = "Unused days from previous")]
        public int AdditionalDaysPast =>
            (HireDate.Value.Year >= DateTime.Now.Year ? 0 :

                (PossibleDaysPast + UnusedDaysPast.Value + Convert.ToInt32(XtraDaysPast) - UsedDaysPast > StandardDays ? StandardDays : PossibleDaysPast + UnusedDaysPast.Value + Convert.ToInt32(XtraDaysPast) - UsedDaysPast )
            );

        // käesoleval aastal aeguvate puhkusepäevade arv
        [Display(Name = "Expiring days")]
        public int LostDaysCurrent => AdditionalDaysPast + XtraDaysCurrent;

        // Käesoleval aastal kasutavate staažipäevade arv
        [Display(Name = "Experience days")]
        public int XtraDaysCurrent =>

            (HireDate.Value.Year < DateTime.Now.Year ? 
            ((new DateTime(DateTime.Now.Year, 12, 31) - HireDate.Value).Days / ((4 * 365 + 1) / 4) <= 5 ? ((new DateTime(DateTime.Now.Year, 12, 31) - HireDate.Value).Days / ((4 * 365 + 1) / 4)) : 5)
            : 0);

        //Käesoleval aastal kasutada olevate PÕHIpuhkusepäevade arv (sisaldab staažipäevi)
        [Display(Name = "Current year total")]
        public int? PossibleDaysCurrent =>
               (
                   HireDate.Value.Year == DateTime.Now.Year ? ((StandardDays * (new DateTime(DateTime.Now.Year, 12, 31) - HireDate.Value).Days * 100) / 365) / 100
                  :
                   (HireDate.Value.Year < DateTime.Now.Year && Created.Year < DateTime.Now.Year ? StandardDays + XtraDaysCurrent + AdditionalDaysPast
                  :
                    (HireDate.Value.Year < DateTime.Now.Year && Created.Year == DateTime.Now.Year ? StandardDays + XtraDaysCurrent + UnusedDaysPast : 0))
                );

        //Käesoleval aastal olevate KINNITATUD (State = 1) PÕHIpuhkusepäevade arv
        [Display(Name = "Confirmed days ")]
        public int ApprovedDaysCurrent =>
            Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (x.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1 :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              (x.EndDate.Value - x.StartDate.Value).Days + 1
                               :
                               (new DateTime(DateTime.Now.Year, 12, 31) - x.StartDate.Value).Days + 1

                             ))
                    .Sum()

                -

             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), x.EndDate.Value).Count()) :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count()
                               :
                               DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()
                             ))
                    .Sum();

        //Käesoleval aastal olevate KINNITATUD (State = 1) ÕPPEpuhkusepäevade arv
        [Display(Name = "Confirmed study leave days")]
        public int ApprovedEducationalCurrent =>
            Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 2)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (x.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1 :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              (x.EndDate.Value - x.StartDate.Value).Days + 1
                               :
                               (new DateTime(DateTime.Now.Year, 12, 31) - x.StartDate.Value).Days + 1

                             ))
                    .Sum()

                -

             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 2)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), x.EndDate.Value).Count()) :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count()
                               :
                               DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()

                             ))
                    .Sum();

        //Käesoleval aastal olevate KINNITATUD (State = 1) MUUDE puhkusepäevade arv
        [Display(Name = "Confirmed other leave days")]
        public int ApprovedOtherCurrent =>
            Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 3)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (x.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1 :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              (x.EndDate.Value - x.StartDate.Value).Days + 1
                               :
                               (new DateTime(DateTime.Now.Year, 12, 31) - x.StartDate.Value).Days + 1

                             ))
                    .Sum()

                -

             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 3)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), x.EndDate.Value).Count()) :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count()
                               :
                               DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()

                             ))
                    .Sum();

        //Käesoleval aastal olevate KINNITATAMISE OOTEL (State = 0) PÕHIpuhkusepäevade arv
        [Display(Name = "Submitted days")]
        public int SubmittedDaysCurrent =>
            Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (x.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1 :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              (x.EndDate.Value - x.StartDate.Value).Days + 1
                               :
                               (new DateTime(DateTime.Now.Year, 12, 31) - x.StartDate.Value).Days + 1

                             ))
                    .Sum()
                -

             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), x.EndDate.Value).Count()) :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count()
                               :
                               DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()

                             ))
                    .Sum();

        //Käesoleval aastal olevate KINNITUSE OOTEL (State = 0) ÕPPEpuhkusepäevade arv
        [Display(Name = "Submitted study leave days")]
        public int SubmittedEducationalCurrent =>
            Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 2)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (x.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1 :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              (x.EndDate.Value - x.StartDate.Value).Days + 1
                               :
                               (new DateTime(DateTime.Now.Year, 12, 31) - x.StartDate.Value).Days + 1

                             ))
                    .Sum()

                -

             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 2)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), x.EndDate.Value).Count()) :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count()
                               :
                               DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()

                             ))
                    .Sum();


        //Käesoleval aastal olevate KINNITAMISE OOTEL (State = 0) MUUDE puhkusepäevade arv
        [Display(Name = "Submitted other leave days ")]
        public int SubmittedOtherCurrent =>
            Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 3)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (x.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1 :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              (x.EndDate.Value - x.StartDate.Value).Days + 1
                               :
                               (new DateTime(DateTime.Now.Year, 12, 31) - x.StartDate.Value).Days + 1

                             ))
                    .Sum()

                -

             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 3)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Select(x =>

                            x.StartDate.Value.Year < DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                             (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), x.EndDate.Value).Count()) :
                             (
                              x.StartDate.Value.Year == DateTime.Now.Year && x.EndDate.Value.Year == DateTime.Now.Year ?
                              DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count()
                               :
                               DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()

                             ))
                    .Sum();


        //Käesoleval aastal veel kasutada olevate PÕHIpuhkusepäevade arv (KASUTADA OLEVAD - KINNITATUD)
        [Display(Name = "Available annual leave days ")]
        public int? AvailableDaysCurrent => PossibleDaysCurrent - ApprovedDaysCurrent;


        //Käesoleval aastal veel Märkimiseks saada olevate PÕHIpuhkusepäevade arv (KASUTADA OLEVAD - KINNITATUD - Kinnitamise ootel)
        [Display(Name = "Available days")]
        public int? FreeDaysCurrent => PossibleDaysCurrent - ApprovedDaysCurrent - SubmittedDaysCurrent;

        //Mitu "KINNITATUD" olevat PÕHIpuhkust kasutajal on (State = 1 )
        public int CountApprovedCurrent =>
             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Count();


        //Mitu "KINNITAMISE OOTEL" olevat PÕHIpuhkust kasutajal on (State = 0 )
        public int CountSubmittedCurrent =>
             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 1)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Count();
       
        
        //Mitu "KINNITATUD" olevat ÕPPEpuhkust kasutajal on (State = 1 )
        public int CountApprovedEducational =>
             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 2)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Count();


        //Mitu "KINNITAMISE OOTEL" olevat ÕPPEpuhkust kasutajal on (State = 0 )
        public int CountSubmittedEducational =>
             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 2)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Count();

        //Mitu "KINNITATUD" olevat MUUDpuhkust kasutajal on (State = 1 )
        public int CountApprovedOther =>
             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 3)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 1)
                  .Count();


        //Mitu "KINNITAMISE OOTEL" olevat MUUDpuhkust kasutajal on (State = 0 )
        public int CountSubmittedOther =>
             Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.CategoryId == 3)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Count();

        //Mitu "KINNITAMISE OOTEL" olevat puhkust manageril on (State = 0 )
        public int CountSubmittedManager =>
            Vacations
                  .Where(x => x.StartDate.Value.Year == DateTime.Now.AddYears(-1).Year || x.StartDate.Value.Year == DateTime.Now.Year)
                  .Where(x => x.EndDate.Value.Year == DateTime.Now.Year || x.EndDate.Value.Year == DateTime.Now.AddYears(+1).Year)
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Count();
    }

}

namespace VacApp_V0._1.Controllers
{
    
    [MetadataType(typeof(PersonMetadata))]
    [Authorize(Roles ="manager,accountant, admin")]
    public class PeopleController : MyController
    {

        private VacationEntities db = new VacationEntities();

        // GET: People
        public ActionResult Index(string searchString, string departmentSort = "")
        {
            var persons =
                (User.IsInRole("admin") || User.IsInRole("accountant") ?
                (db.People
                .Where(x => departmentSort == "" || departmentSort == x.Department.Name)
                .OrderBy(x => x.LastName))
                :
                (db.People
                .Where(x => x.DepartmentId == CurrentPerson.DepartmentId)
                .Where(x => departmentSort == "" || departmentSort == x.Department.Name)
                .OrderBy(x => x.LastName)));



            var people = from s in persons
                         select s;

            if (!String.IsNullOrEmpty(searchString))

            {
                people = people.Where(s => s.LastName.Contains(searchString));
            }

            ViewBag.departmentSort =
                new SelectList(db.Departments.Select(x => new { x.Name }).Distinct(), "Name", "Name", departmentSort);



            return View(people.ToList());
        }

        // GET: People/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Person person = db.People.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
            return View(person);
        }

        // GET: People/Create
        [Authorize(Roles = "manager, admin")]
        public ActionResult Create()
        {
            
            ViewBag.DepartmentId =

               User.IsInRole("admin") ?
               new SelectList(db.Departments.Where(x => x.Name != "Former Employees"), "Id", "Name") :
               new SelectList(db.Departments.Where(x => x.Id == CurrentPerson.DepartmentId), "Id", "Name")
               ;
                                                               
            return View(new Person { HireDate = DateTime.Today});
        }

        // POST: People/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,FirstName,LastName,IK,DepartmentId,Position,HireDate,StandardDays,UnusedDaysPast,UnusedDaysCurrent,ExtraDays,PictureId,Created,Modified,Email")] Person person, HttpPostedFileBase file)
        {
            
            try
            {
                if (person.IK?.Length < 11)
                    ModelState.AddModelError("", "Isikukood must be at least 11 digits long");

                if (person.HireDate == null)
                    ModelState.AddModelError("", "The field \"Hire date\" cannot be empty");

            }
            catch (Exception)
            {

            }
            

            if (ModelState.IsValid)
            {
                person.Created = DateTime.Now;
                person.Modified = DateTime.Now;

                db.People.Add(person);
                db.SaveChanges();

                if (file != null && file.ContentLength > 0)
                    using (BinaryReader br = new BinaryReader(file.InputStream))
                    {
                       
                        DataFile f = new DataFile
                        {
                            Content = br.ReadBytes(file.ContentLength),
                            ContentType = file.ContentType,
                            FileName = file.FileName.Split('\\').Last().Split('/').Last(),
                            Created = DateTime.Now
                        };
                        db.DataFiles.Add(f);
                        db.SaveChanges();

                        int? oldPictureId = person.PictureId;
                        person.PictureId = f.Id;
                        db.SaveChanges();

                        if (oldPictureId != null)
                        {
                            db.DataFiles.Remove(db.DataFiles.Find(oldPictureId.Value));
                            db.SaveChanges();
                        }

                    }

                return RedirectToAction("Index");

            }
            
            ViewBag.DepartmentId = new SelectList(db.Departments, "Id", "Name", person.DepartmentId);
            return View(person);

           
        }

        // GET: People/Edit/5
        [Authorize(Roles = "manager, admin")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Person person = db.People.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
          
            ViewBag.DepartmentId =

               User.IsInRole("admin") ?
               new SelectList(db.Departments, "Id", "Name", person.DepartmentId) :
               new SelectList(db.Departments.Where(x => x.Id == CurrentPerson.DepartmentId), "Id", "Name", person.DepartmentId)
               ;

            return View(person);
        }

        // POST: People/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,IK,DepartmentId,Position,HireDate,StandardDays,UnusedDaysPast,UnusedDaysCurrent,ExtraDays,PictureId,Created,Modified,Email")] Person person, HttpPostedFileBase file)
        {
            if (person.Modified == null)
                person.Modified = DateTime.Now;


            if (ModelState.IsValid)
            {
                if (db.ChangeTracker.HasChanges()) person.Modified = DateTime.Now; 


                db.Entry(person).State = EntityState.Modified;
                db.Entry(person).Property("PictureId").IsModified = false;
                db.SaveChanges();

                //lisasin MyControlleri alla ChangeDataFile

                ChangeDataFile(file, x => { person.PictureId = x; db.SaveChanges(); }, person.PictureId);

                if (file != null && file.ContentLength > 0)
                    using (BinaryReader br = new BinaryReader(file.InputStream))
                    {
                            DataFile f = new DataFile
                            {
                                Content = br.ReadBytes(file.ContentLength),
                                ContentType = file.ContentType,
                                FileName = file.FileName.Split('\\').Last().Split('/').Last(),
                                Created = DateTime.Now
                            };
                            db.DataFiles.Add(f);
                            db.SaveChanges();

                            int? oldPictureId = person.PictureId;
                            person.PictureId = f.Id;
                            db.SaveChanges();

                            if (oldPictureId != null)
                            {
                                db.DataFiles.Remove(db.DataFiles.Find(oldPictureId.Value));
                                db.SaveChanges();
                            }

                       
                    }
                
                return RedirectToAction("Index");

            }

            
            ViewBag.DepartmentId = new SelectList(db.Departments, "Id", "Name", person.DepartmentId);
            return View(person);
        }

       
        [Authorize(Roles = "admin")]
        // GET: People/Delete/5
        [Authorize(Roles = "manager, admin")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Person person = db.People.Find(id);
            if (person == null)
            {
                return HttpNotFound();
            }
            return View(person);
        }

        // POST: People/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Person person = db.People.Find(id);
            db.People.Remove(person);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}