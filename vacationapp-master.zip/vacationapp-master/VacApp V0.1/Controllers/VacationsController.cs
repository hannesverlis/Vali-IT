﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VacApp_V0._1.Models;
using Microsoft.Ajax.Utilities;
using Nager.Date;

namespace VacApp_V0._1.Models
{
    public partial class Vacation
    {
        static Dictionary<int, string> States = new Dictionary<int, string>
        {
            {0, "Pending" },
            {1, "Confirmed" },
            {2, "Denied" },
        };
        public string StateName => States[State];
    }
}

namespace VacApp_V0._1.Controllers
{
    [Authorize]
    public class VacationsController : MyController
    {
        static Dictionary<int, string> StateData = new Dictionary<int, string>
        {
            {0, "Pending" },
            {1, "Confirmed" },
            {2, "Denied" },
        };

        static Dictionary<int, string> DateFilterData = new Dictionary<int, string>
        {
            {0, "Future vacations" },
            {1, "Past vacations" },
        };

        private VacationEntities db = new VacationEntities();

        // GET: Vacations
        public ActionResult Index(string searchString, string departmentSort = "", int? stateSort = null, int? pastFuture = 0)
        {            
            var vacations =
            #region db vacations

                pastFuture == 0 ?

               ((User.IsInRole("admin") || User.IsInRole("accountant") ?
               (db.Vacations
               .Where(x => x.EndDate > DateTime.Now)
               .Where(x => departmentSort == "" || departmentSort == x.Person.Department.Name)
               .Where(x => stateSort == null || stateSort == x.State)
               .OrderBy(x => x.StartDate)
               )
               :
               (db.Vacations
               .Where(x => x.EndDate > DateTime.Now)
               .Where(x => x.Person.DepartmentId == CurrentPerson.DepartmentId)
               .Where(x => departmentSort == "" || departmentSort == x.Person.Department.Name)
               .Where(x => stateSort == null || stateSort == x.State)
               .OrderBy(x => x.StartDate)
               )))

               :
               ((User.IsInRole("admin") || User.IsInRole("accountant") ?
               (db.Vacations
               .Where(x => x.EndDate < DateTime.Now)
               .Where(x => departmentSort == "" || departmentSort == x.Person.Department.Name)
               .Where(x => stateSort == null || stateSort == x.State)
               .OrderByDescending(x => x.StartDate)
               )
               :
               (db.Vacations
               .Where(x => x.EndDate < DateTime.Now)
               .Where(x => x.Person.DepartmentId == CurrentPerson.DepartmentId)
               .Where(x => departmentSort == "" || departmentSort == x.Person.Department.Name)
               .Where(x => stateSort == null || stateSort == x.State)
               .OrderByDescending(x => x.StartDate)
               )))
               ; 
            #endregion

            var people = from s in vacations
                         select s;

            if (!String.IsNullOrEmpty(searchString))
            {
                people = people.Where(s => s.Person.LastName.Contains(searchString));
            }

            ViewBag.departmentSort =
                new SelectList(db.Departments.Select(x => new { x.Name }).Distinct(), "Name", "Name", departmentSort);
            
            ViewBag.stateSort = new SelectList(StateData, "Key", "Value", stateSort);

            ViewBag.pastFuture = new SelectList(DateFilterData, "Key", "Value", pastFuture);

            ViewBag.CurrentUserId = CurrentPerson.Id;

            return View(people.ToList());
        }

        public ActionResult FilterState(string SearchString)
        {
            var states = from s in db.Vacations
                         select s;

            if (!String.IsNullOrEmpty(SearchString))

            {
                states = states.Where(s => s.StateName.Contains(SearchString));

            }
            return View(states.ToList());
        }
        public ActionResult ChangeState(int id, int newstate)
        {
            db.Vacations.Find(id).State = newstate;
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        // GET: Vacations/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vacation vacation = db.Vacations.Find(id);
            if (vacation == null)
            {
                return HttpNotFound();
            }
            return View(vacation);
        }

        // GET: Vacations/Create
        public ActionResult Create()
        {
            var vacationsCreate = db.Vacations.Include(v => v.Person);
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name");


            ViewBag.PersonId =

                User.IsInRole("admin") || User.IsInRole("accountant") ?
                new SelectList(db.People.Where(x => x.FirstName != "Admin").Where(x => x.Department.Name != "Former Employees"), "Id", "FullName") :

                (
                User.IsInRole("manager") ?
                new SelectList(CurrentPerson.Department.People, "Id", "FullName") :

                new SelectList(db.People.Where(x => CurrentUser.Email == x.Email), "Id", "FullName")
                )
                ;
           
            
            return View();
        }

        public ActionResult AddAttachment(int id, string comment, int vacationId, HttpPostedFileBase file)
        {
            if (file != null)
            {
                using (BinaryReader br = new BinaryReader(file.InputStream))
                {
                    try
                    {
                        db.Database.BeginTransaction();
                        DataFile f = new DataFile
                        {
                            FileName = Path.GetFileName(file.FileName),
                            ContentType = file.ContentType,
                            Content = br.ReadBytes(file.ContentLength)
                        };
                        db.DataFiles.Add(f);
                        db.SaveChanges(); //siin saab f omale id

                        db.Attachments.Add(
                                  new Attachment
                                  {
                                      VacationId = vacationId,
                                      Comment = comment,
                                      FileId = f.Id
                                  });
                        db.SaveChanges();  //andmebaasi peaks minema attachment
                        db.Database.CurrentTransaction.Commit();
                    }
                    catch (Exception)
                    {
                    }
                }
            }
            return RedirectToAction("Edit", new { id });
        }

        public ActionResult Calendar(int? month, int? year, string departmentSort = "") 
        {            
            int monthv = month ?? DateTime.Today.Month;
            int yearv = year ?? DateTime.Today.Year;
            // kaks parameetrit, puudumisel võtame jooskva aasta ja/või jooksva kuu

            DateTime startdate = new DateTime(yearv, monthv, 1); // kuu algus
            DateTime calstart = startdate.AddDays(-(((int)startdate.DayOfWeek + 6) % 7));
            // mis kuupäevast peaks algama kalender 

            // kõik 4 paneme viewsse kaasa
            ViewBag.StartDate = startdate;
            ViewBag.CalStart = calstart;
            ViewBag.Month = monthv;
            ViewBag.Year = yearv;
            // Nüüd teeme kuus nädalat kuupäevi
            ViewBag.Dates = Enumerable
                .Range(0, 42)               // kuus nädalat (42)
                .GroupBy(x => x / 7)        // grupeerime 7 kaupa
                .Select(x => x.Select(y => calstart.AddDays(y)).ToList())
            // iga grupi teisendame kuupäevade listiks
            .ToList()       // ja kõik need grupid paneme omakorda listi
            ;
            // tulemuseks on umbes Datetime[6][7] massiiv, aga tegelikult List<List<DateTime>>

            // aga viewle mudeliks anname oma taskid - läheme nüüd seda viewd vaatama

            ViewBag.PersonVacationData = db.People.Where(x => CurrentUser.Email == x.Email).ToList();

            

            int currentYear = DateTime.Now.Year;

            ViewBag.SubmittedVacationsRemainder = 
                db.Vacations
                .Where(x => x.StartDate.Value.Year == (currentYear -1) || x.StartDate.Value.Year == currentYear)
                  .Where(x => x.EndDate.Value.Year == currentYear || x.EndDate.Value.Year == (currentYear+1))
                  .Where(x => x.StartDate > x.Person.HireDate)
                  .Where(x => x.State == 0)
                  .Where(x => x.Person.DepartmentId == CurrentPerson.DepartmentId)
                  .Count();

            var vacations =

                User.IsInRole("admin") || User.IsInRole("accountant") ?
                (db.Vacations
                .Where(x => x.State != 2)
                .Where(x => x.Person.Department.Name != "Former employees")
                .Where(x => departmentSort == "" || departmentSort == x.Person.Department.Name)
                .ToList())
                :
                (db.Vacations
                .Where(x => x.State != 2)
                .Where(x => x.Person.DepartmentId == CurrentPerson.DepartmentId)
                .ToList());

            ViewBag.departmentSort =
                new SelectList(db.Departments.Where(x => x.Name != "Former employees").Select(x => new { x.Name }).Distinct(), "Name", "Name", departmentSort);

            return View(vacations);

        }
        // POST: Vacations/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,PersonId,StartDate,EndDate,Duration,Notes,State,CategoryId")] Vacation vacation)
        {

            #region Overlapping
            bool overlapping = false;

            foreach (var v in db.Vacations.Where(x => x.PersonId == vacation.PersonId))
            {
                if (vacation.StartDate <= v.EndDate && vacation.EndDate >= v.StartDate)
                {
                    overlapping = true;
                }
            }
            #endregion


            #region IF conditions for ModelState
            try
            {

                if (!User.IsInRole("accountant") && !User.IsInRole("admin") && (vacation.StartDate.Value - DateTime.Now).Days < 7)
                    ModelState.AddModelError("StartDate7Days", "Start date of the vacation must be at least 7 days ahead!");

                if (User.IsInRole("accountant") && !User.IsInRole("admin") && vacation.StartDate < DateTime.Now.AddMonths(-3))
                    ModelState.AddModelError("StartDate8", "Start date of the vacation cannot be earlier than 3 months into the past");

                if (overlapping == true)
                    ModelState.AddModelError("", "Vacation is overlapping with existing vacation!");

                if (vacation.StartDate > vacation.EndDate)
                    ModelState.AddModelError("StartDate1", "Start date cannot be later than end date!");

                if (vacation.StartDate < new DateTime(DateTime.Now.Year, 1, 1).AddMonths(-1))
                    ModelState.AddModelError("StartDate2", "Start date cannot be earlier than 1st December last year");

                if (vacation.StartDate < db.People.Find(vacation.PersonId).Created)
                    ModelState.AddModelError("StartDate3", "Start date cannot be earlier than the date the person was added to the database!");

                if (vacation.StartDate < db.People.Find(vacation.PersonId).HireDate)
                    ModelState.AddModelError("StartDate4", "Start date cannot be earlier than the date the person was hired!");

                if (vacation.StartDate > new DateTime(DateTime.Now.Year, 12, 31).AddYears(1))
                    ModelState.AddModelError("StartDate5", "Start date cannot be later than 31th of December next year!");


                if (vacation.CategoryId == 1 && vacation.StartDate > new DateTime(DateTime.Now.Year, 1, 31).AddYears(1))
                    ModelState.AddModelError("StartDate6", "Start date of annual leave cannot be later than 31th of january next year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year >= DateTime.Now.Year && vacation.EndDate > new DateTime(DateTime.Now.Year, 1, 31).AddYears(1))
                    ModelState.AddModelError("EndDate1", "End date of annual leave cannot be later than 31th of January next year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), vacation.EndDate.Value).Count()) > db.People.Find(vacation.PersonId).AvailableDaysCurrent - db.People.Find(vacation.PersonId).SubmittedDaysCurrent)
                    ModelState.AddModelError("", "Duration period in the current year cannot exceed the amount of non-submitted available vacation days in the current year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, vacation.EndDate.Value).Count()) > db.People.Find(vacation.PersonId).AvailableDaysCurrent - db.People.Find(vacation.PersonId).SubmittedDaysCurrent)
                    ModelState.AddModelError("", "Duration period in the current year cannot exceed the amount of non-submitted available vacation days in the current year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year && ((new DateTime(DateTime.Now.Year, 12, 31) - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()) > db.People.Find(vacation.PersonId).AvailableDaysCurrent - db.People.Find(vacation.PersonId).SubmittedDaysCurrent)
                    ModelState.AddModelError("", "Duration period in the current year cannot exceed the amount of non-submitted available vacation days in the current year!");


                if (vacation.CategoryId == 2 && vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), vacation.EndDate.Value).Count()) > 45 - db.People.Find(vacation.PersonId).SubmittedEducationalCurrent - db.People.Find(vacation.PersonId).ApprovedEducationalCurrent)
                    ModelState.AddModelError("", "Duration period of the study leave in the current year cannot exceed 45 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, vacation.EndDate.Value).Count()) > 45 - db.People.Find(vacation.PersonId).SubmittedEducationalCurrent - db.People.Find(vacation.PersonId).ApprovedEducationalCurrent)
                    ModelState.AddModelError("", "Duration period of the study leave in the current year cannot exceed 45 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year && ((new DateTime(DateTime.Now.Year, 12, 31) - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()) > 45 - db.People.Find(vacation.PersonId).SubmittedEducationalCurrent - db.People.Find(vacation.PersonId).ApprovedEducationalCurrent)
                    ModelState.AddModelError("", "Duration period of the study leave in the current year cannot exceed 45 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.Notes == null && vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), vacation.EndDate.Value).Count()) > 30 - db.People.Find(vacation.PersonId).SubmittedEducationalCurrent - db.People.Find(vacation.PersonId).ApprovedEducationalCurrent)
                    ModelState.AddModelError("Notes2", "Notes field must be filled if the amount of used study leave days exceeds 30 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.Notes == null && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, vacation.EndDate.Value).Count()) > 30 - db.People.Find(vacation.PersonId).SubmittedEducationalCurrent - db.People.Find(vacation.PersonId).ApprovedEducationalCurrent)
                    ModelState.AddModelError("Notes2", "Notes field must be filled if the amount of used study leave days exceeds 30 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.Notes == null && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year && ((new DateTime(DateTime.Now.Year, 12, 31) - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()) > 30 - db.People.Find(vacation.PersonId).SubmittedEducationalCurrent - db.People.Find(vacation.PersonId).ApprovedEducationalCurrent)
                    ModelState.AddModelError("Notes2", "Notes field must be filled if the amount of used study leave days exceeds 30 days in the current year!");

                if (vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year)
                    ModelState.AddModelError("", "Maximum duration of vacation has been exceeded!");

                if (vacation.CategoryId == 3 && vacation.Notes == null)
                    ModelState.AddModelError("Notes1", "Notes field must be filled for other type of vacations!");

            }
            catch (Exception)
            {
            }

            #endregion


            if (ModelState.IsValid)
            {
                // puhkuse DURATION (siin ei arvesta riigipühasid)
                vacation.Duration = (vacation.EndDate.Value - vacation.StartDate.Value).Days + 1;

                db.Vacations.Add(vacation);
                db.SaveChanges();
                if (CurrentPerson.Id == vacation.Person.Id && vacation.CategoryId != 2)
                {
                    return RedirectToAction("Calendar");
                }
                if (vacation.CategoryId == 2)
                {
                    return RedirectToAction("Edit", vacation);
                }
                else
                {
                    return RedirectToAction("Index");
                }
            }
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name", vacation.CategoryId);
            ViewBag.PersonId = new SelectList(db.People, "Id", "FullName", vacation.PersonId);
            ViewBag.AvaliableDays = CurrentPerson.AvailableDaysCurrent;
            ViewBag.Name = CurrentPerson.FullName;
            return View(vacation);
        }

        // GET: Vacations/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vacation vacation = db.Vacations.Find(id);
            if (vacation == null)
            {
                return HttpNotFound();
            }
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name", vacation.CategoryId);

            #region Attachment existing control
            int numberOfAttachments = vacation.Attachments.Where(x => x.VacationId == vacation.Id).Count();

            ViewBag.HasAttachment = numberOfAttachments;
            #endregion

            ViewBag.VacationCategory = vacation.CategoryId;

            ViewBag.PersonId =

               User.IsInRole("admin") || User.IsInRole("accountant") ?
               new SelectList(db.People.Where(x => x.Department.Name != "Former Employees"), "Id", "FullName", vacation.PersonId) :
               (
               User.IsInRole("manager") ?
               new SelectList(CurrentPerson.Department.People, "Id", "FullName", vacation.PersonId) :

               new SelectList(db.People.Where(x => CurrentUser.Email == x.Email), "Id", "FullName", vacation.PersonId)
               )
               ;
            return View(vacation);
        }

        // POST: Vacations/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,PersonId,StartDate,EndDate,Duration,Notes,State,CategoryId")] Vacation vacation)
        {

            #region EditMarkedDays
            int currentYear = DateTime.Now.Year;
            DateTime startCurrentYear = new DateTime(currentYear, 1, 1);
            DateTime endCurrentYear = new DateTime(currentYear, 12, 31);

            int EditMarkedDays =
                db.Vacations
                      .Where(x => x.PersonId == vacation.PersonId)
                      .Where(x => x.Id != vacation.Id)
                      .Where(x => x.StartDate.Value.Year == currentYear - 1 || x.StartDate.Value.Year == currentYear)
                      .Where(x => x.EndDate.Value.Year == currentYear || x.EndDate.Value.Year == currentYear + 1)
                      .Where(x => x.CategoryId == vacation.CategoryId)
                      .Where(x => x.StartDate > x.Person.HireDate)
                      .Where(x => x.State != 2)
                      .ToList()
                      .Select(x =>

                                (x.StartDate.Value.Year < currentYear && x.EndDate.Value.Year == currentYear) ?
                                 (x.EndDate.Value - startCurrentYear).Days + 1 :
                                 (
                                  (x.StartDate.Value.Year == currentYear && x.EndDate.Value.Year == currentYear) ?
                                  (x.EndDate.Value - x.StartDate.Value).Days + 1
                                   :
                                   (endCurrentYear - x.StartDate.Value).Days + 1

                                 ))
                        .Sum()

                    -

                 db.Vacations
                      .Where(x => x.PersonId == vacation.PersonId)
                      .Where(x => x.Id != vacation.Id)
                      .Where(x => x.StartDate.Value.Year == currentYear - 1 || x.StartDate.Value.Year == currentYear)
                      .Where(x => x.EndDate.Value.Year == currentYear || x.EndDate.Value.Year == currentYear + 1)
                      .Where(x => x.CategoryId == vacation.CategoryId)
                      .Where(x => x.StartDate > x.Person.HireDate)
                      .Where(x => x.State != 2)
                      .ToList()
                      .Select(x =>

                                (x.StartDate.Value.Year < currentYear && x.EndDate.Value.Year == currentYear) ?
                                 (DateSystem.GetPublicHoliday(CountryCode.EE, startCurrentYear, x.EndDate.Value).Count()) :
                                 (
                                  (x.StartDate.Value.Year == currentYear && x.EndDate.Value.Year == currentYear) ?
                                  DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, x.EndDate.Value).Count()
                                   :
                                   DateSystem.GetPublicHoliday(CountryCode.EE, x.StartDate.Value, endCurrentYear).Count()

                                 ))
                        .Sum();
            #endregion


            #region Overlapping
            bool overlapping = false;

            foreach (var v in db.Vacations.Where(x => x.PersonId == vacation.PersonId).Where(x => x.Id != vacation.Id))
            {
                if (vacation.StartDate <= v.EndDate && vacation.EndDate >= v.StartDate)
                {
                    overlapping = true;
                }
            }
            #endregion


            #region IF conditions for ModelState

            try
            {
                if (!User.IsInRole("accountant") && !User.IsInRole("admin") && (vacation.StartDate.Value - DateTime.Now).Days < 7)
                    ModelState.AddModelError("StartDate7Days", "Start date of the vacation must be at least 7 days ahead!");

                if (User.IsInRole("accountant") && !User.IsInRole("admin") && vacation.StartDate < DateTime.Now.AddMonths(-3))
                    ModelState.AddModelError("StartDate8", "Start date of the vacation cannot be earlier than 3 months into the past");

                if (overlapping == true)
                    ModelState.AddModelError("", "Vacation is overlapping with existing vacation!");

                if (vacation.StartDate < new DateTime(DateTime.Now.Year, 1, 1).AddMonths(-1))
                    ModelState.AddModelError("StartDate2", "Start date cannot be earlier than 1st December last year");

                if (vacation.StartDate > vacation.EndDate)
                    ModelState.AddModelError("StartDate1", "Start date cannot be later than end date!");

                if (vacation.EndDate < new DateTime(DateTime.Now.Year, 1, 1).AddMonths(-1))
                    ModelState.AddModelError("EndDate2", "Vacations which ended before 1st December last year cannot be edited");

                if (vacation.StartDate < db.People.Find(vacation.PersonId).Created)
                    ModelState.AddModelError("StartDate3", "Start date cannot be earlier than the date the person was added to the database!");

                if (vacation.StartDate < db.People.Find(vacation.PersonId).HireDate)
                    ModelState.AddModelError("StartDate4", "Start date cannot be earlier than the date the person was hired!");

                if (vacation.StartDate > new DateTime(DateTime.Now.Year, 12, 31).AddYears(1))
                    ModelState.AddModelError("StartDate5", "Start date cannot be later than 31th of December next year!");

                if (vacation.CategoryId == 1 && vacation.StartDate > new DateTime(DateTime.Now.Year, 1, 31).AddYears(1))
                    ModelState.AddModelError("StartDate6", "Start date of annual leave cannot be later than 31th of january next year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year >= DateTime.Now.Year && vacation.EndDate > new DateTime(DateTime.Now.Year, 1, 31).AddYears(1))
                    ModelState.AddModelError("EndDate1", "End date of annual leave cannot be later than 31th of January next year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), vacation.EndDate.Value).Count()) > db.People.Find(vacation.PersonId).PossibleDaysCurrent - EditMarkedDays)
                    ModelState.AddModelError("", "Duration period in the current year cannot exceed the amount of non-submitted available vacation days in the current year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, vacation.EndDate.Value).Count()) > db.People.Find(vacation.PersonId).PossibleDaysCurrent - EditMarkedDays)
                    ModelState.AddModelError("", "Duration period in the current year cannot exceed the amount of non-submitted available vacation days in the current year!");

                if (vacation.CategoryId == 1 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year && ((new DateTime(DateTime.Now.Year, 12, 31) - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()) > db.People.Find(vacation.PersonId).PossibleDaysCurrent - EditMarkedDays)
                    ModelState.AddModelError("", "Duration period in the current year cannot exceed the amount of non-submitted available vacation days in the current year!");


                if (vacation.CategoryId == 2 && vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), vacation.EndDate.Value).Count()) > 45 - EditMarkedDays)
                    ModelState.AddModelError("", "Duration period of the study leave in the current year cannot exceed 45 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, vacation.EndDate.Value).Count()) > 45 - EditMarkedDays)
                    ModelState.AddModelError("", "Duration period of the study leave in the current year cannot exceed 45 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year && ((new DateTime(DateTime.Now.Year, 12, 31) - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()) > 45 - EditMarkedDays)
                    ModelState.AddModelError("", "Duration period of the study leave in the current year cannot exceed 45 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.Notes == null && vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - new DateTime(DateTime.Now.Year, 1, 1)).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, new DateTime(DateTime.Now.Year, 1, 1), vacation.EndDate.Value).Count()) > 30 - EditMarkedDays)
                    ModelState.AddModelError("Notes2", "Notes field must be filled if the amount of used study leave days exceeds 30 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.Notes == null && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year == DateTime.Now.Year && ((vacation.EndDate.Value - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, vacation.EndDate.Value).Count()) > 30 - EditMarkedDays)
                    ModelState.AddModelError("Notes2", "Notes field must be filled if the amount of used study leave days exceeds 30 days in the current year!");

                if (vacation.CategoryId == 2 && vacation.Notes == null && vacation.StartDate.Value.Year == DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year && ((new DateTime(DateTime.Now.Year, 12, 31) - vacation.StartDate.Value).Days + 1) - (DateSystem.GetPublicHoliday(CountryCode.EE, vacation.StartDate.Value, new DateTime(DateTime.Now.Year, 12, 31)).Count()) > 30 - EditMarkedDays)
                    ModelState.AddModelError("Notes2", "Notes field must be filled if the amount of used study leave days exceeds 30 days in the current year!");

                if (vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year)
                    ModelState.AddModelError("", "Maximum duration of vacation has been exceeded!");



                if (vacation.StartDate.Value.Year < DateTime.Now.Year && vacation.EndDate.Value.Year > DateTime.Now.Year)
                    ModelState.AddModelError("", "Maximum duration of vacation has been exceeded!");

                //if (vacation.CategoryId == 2 && faili ei ole lisatud) // See on tingimus, et õppepuhkusel peaks fail olema kaasas
                //    ModelState.AddModelError("", "Statement file must be added for Study leave!");

                if (vacation.CategoryId == 3 && vacation.Notes == null)
                    ModelState.AddModelError("Notes1", "Notes field must be filled for other types of vacations!");

            }
            catch (Exception)
            {
            }

            #endregion


            if (ModelState.IsValid)
            {
                vacation.Duration = (vacation.EndDate.Value - vacation.StartDate.Value).Days + 1;

               
                if (vacation.Id == 0)
                {
                    db.Vacations.Add(vacation);
                    db.SaveChanges();
                }
                else
                {
                    using (var context = new VacationEntities())
                    {
                        context.Entry(vacation).State = EntityState.Modified;
                        context.SaveChanges();
                    }
                }

                return RedirectToAction("Index");
            }
                  
            ViewBag.CategoryId = new SelectList(db.Categories, "Id", "Name", vacation.CategoryId);
            ViewBag.PersonId = new SelectList(db.People, "Id", "FullName", vacation.PersonId);
            return View(vacation);
        }

        // GET: Vacations/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Vacation vacation = db.Vacations.Find(id);
            if (vacation == null)
            {
                return HttpNotFound();
            }
            return View(vacation);
        }

        // POST: Vacations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            DateTime? vacationStart = db.Vacations.Find(id).StartDate;

            #region DELETE IF CONDITIONS
            if (User.IsInRole("admin"))
            {
                var puhkus = db.Vacations.Find(id);

                var failid = puhkus.Attachments.Select(x => x.FileId).ToList();

                foreach (Attachment a in puhkus.Attachments.ToList())
                {
                    db.Attachments.Remove(a);

                }
                db.SaveChanges();

                Vacation vacation = db.Vacations.Find(id);
                db.Vacations.Remove(vacation);
                db.SaveChanges();

                foreach (int i in failid)
                {
                    db.DataFiles.Remove(db.DataFiles.Find(i));
                }
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            if (User.IsInRole("accountant") && !User.IsInRole("admin") && vacationStart > DateTime.Now.AddMonths(-3))
            {
                var puhkus = db.Vacations.Find(id);

                var failid = puhkus.Attachments.Select(x => x.FileId).ToList();

                foreach (Attachment a in puhkus.Attachments.ToList())
                {
                    db.Attachments.Remove(a);

                }
                db.SaveChanges();

                Vacation vacation = db.Vacations.Find(id);
                db.Vacations.Remove(vacation);
                db.SaveChanges();

                foreach (int i in failid)
                {
                    db.DataFiles.Remove(db.DataFiles.Find(i));
                }
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            if (!User.IsInRole("admin") && !User.IsInRole("accountant") && vacationStart > DateTime.Now.AddDays(+7))
            {
                var puhkus = db.Vacations.Find(id);

                var failid = puhkus.Attachments.Select(x => x.FileId).ToList();

                foreach (Attachment a in puhkus.Attachments.ToList())
                {
                    db.Attachments.Remove(a);

                }
                db.SaveChanges();

                Vacation vacation = db.Vacations.Find(id);
                db.Vacations.Remove(vacation);
                db.SaveChanges();

                foreach (int i in failid)
                {
                    db.DataFiles.Remove(db.DataFiles.Find(i));
                }
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index");
            } 
            #endregion

         
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
